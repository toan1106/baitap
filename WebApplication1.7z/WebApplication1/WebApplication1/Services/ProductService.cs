﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.DbContext;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class ProductService : IProductService
    {
        ProductContext _context = new ProductContext();
        public List<ProductViewModel> getAll()
        {
            return _context.Products.ToList();
        }
        public ProductViewModel Product_Detail(int? id)
        {
            return _context.Products.FirstOrDefault(m => m.ID == id);
        }

        public ProductViewModel GetId(int? id)
        {
            return _context.Products.Find(id);
        }

        public bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.ID == id);
        }

        public void UpdateProduct(ProductViewModel product)
        {
            _context.Update(product);
            _context.SaveChangesAsync();
        }

        public void DeleteProduct(ProductViewModel product)
        {
            _context.Products.Remove(product);
            _context.SaveChanges();
        }

        public void CreateProduct(ProductViewModel product)
        {
            _context.Add(product);
            _context.SaveChanges();
        }
    }
}
