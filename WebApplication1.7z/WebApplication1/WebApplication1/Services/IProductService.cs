﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IProductService
    {
        List<ProductViewModel> getAll();
        ProductViewModel Product_Detail(int? id);
        ProductViewModel GetId(int? id);

        bool ProductExists(int id);
        void UpdateProduct(ProductViewModel product);
        void DeleteProduct(ProductViewModel product);
        void CreateProdcut(ProductViewModel product);
    }
}
