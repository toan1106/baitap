﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.DbContext
{
    public class ProductContext: Microsoft.EntityFrameworkCore.DbContext
    {
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProductViewModel>().HasKey(x => x.ID);
            modelBuilder.Entity<ProductViewModel>().Property(x => x.ID).UseIdentityColumn();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            IConfigurationRoot iConfigurationRoot = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
            var connectionString = iConfigurationRoot.GetConnectionString("myconn");
            optionsBuilder.UseSqlServer(connectionString);
        }
        public DbSet<ProductViewModel> Products { get; set; }
    }
}
